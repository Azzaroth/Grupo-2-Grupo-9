/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.controller;

import br.model.Cliente;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.event.ActionEvent;

/**
 *
 * @author azaroth
 */
@ManagedBean(name = "login")
@SessionScoped
public class LoginBean {

    private String email;
    private String senha;

    public String autenticar(ActionEvent actionEvent) {
        Cliente c = new ClienteDAO().validar(this.getEmail(), this.getSenha());
        if (c == null) {
            return "erro.xhtml";
        } else {
            return "sucesso.xhtml";
        }
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

}
