/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.controller;

import br.model.Cliente;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.event.ActionEvent;

/**
 *
 * @author azaroth
 */
@ManagedBean(name = "cliente")
@ViewScoped
public class ClienteBean implements Serializable {

    private Cliente c = new Cliente();

    List clientes = new ArrayList();

    public ClienteBean() {
        clientes = new ClienteDAO().listar();
        c = new Cliente();
    }

    public void cadastrar(ActionEvent actionEvent) {
        new ClienteDAO().inserir(c);
        clientes = new ClienteDAO().listar();
        c = new Cliente();
    }

    public Cliente getC() {
        return c;
    }

    public void setC(Cliente c) {
        this.c = c;
    }

    public List getClientes() {
        return clientes;
    }

    public void setClientes(List clientes) {
        this.clientes = clientes;
    }

}
